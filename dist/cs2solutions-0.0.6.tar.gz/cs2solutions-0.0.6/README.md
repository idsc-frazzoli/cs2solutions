# CS2-solutions
This package contains solutions to be used with the Jupyter-notebooks of the FS24 CS2 lecture.
(c) ETH Zürich