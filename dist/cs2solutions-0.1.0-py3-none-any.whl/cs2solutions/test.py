def test():
    print("test")
    pass

