#(c) 2024 ETH Zurich

def test():
    print("test")
    pass

